"""
=============================================================================
SecureCode AI - Backend Integration Adapter (backend_adapter.py)
=============================================================================
PURPOSE:
Provides a resilient, decoupled bridge between the Streamlit Frontend and
underlying security analysis engines.

INTEGRATION CONTRACT:
- If a teammate's AI/backend module is present (e.g. `backend.ai_engine` or
  `backend.production_scanner`), it invokes that engine.
- If no teammate backend is detected, or if the backend encounters an error,
  it falls back safely to `mock_scanner.analyze_code()`.
- Explicitly tags every finding with its source engine so users and hackathon
  judges know whether results came from a live AI backend or the rule-based fallback.
=============================================================================
"""

import os
import sys
import datetime
from typing import Dict, Any, List, Optional

# Always import local mock scanner as guaranteed fallback
import mock_scanner

# Name tags for transparent reporting
ENGINE_MOCK = "Rule-Based Engine (Fallback Simulation)"
ENGINE_LIVE = "Live Teammate AI Engine"


def is_live_backend_available() -> bool:
    """
    Checks if a live backend module or remote API is configured.
    Looks for `backend.ai_engine` or `SECURECODE_API_ENDPOINT`.
    """
    if os.getenv("SECURECODE_API_ENDPOINT"):
        return True

    # Check for teammate backend Python files in workspace
    try:
        import backend.ai_engine as ai_mod
        if hasattr(ai_mod, "analyze_code"):
            return True
    except (ImportError, AttributeError):
        pass

    return False


def get_active_engine_info() -> Dict[str, Any]:
    """Returns metadata describing the currently active engine."""
    live = is_live_backend_available()
    return {
        "engine_name": ENGINE_LIVE if live else ENGINE_MOCK,
        "is_mock": not live,
        "mode": "Live Production / AI" if live else "Rule-Based Mock / Hackathon Fallback",
        "notice": (
            "Connected to live teammate AI backend." if live else
            "Running in local rule-based simulation mode. Findings are generated via deterministic AST/regex heuristics."
        )
    }


def analyze_code(code: str, language: str = "python") -> Dict[str, Any]:
    """
    Primary standardized entry point for code vulnerability analysis.

    Args:
        code (str): Source code string to inspect.
        language (str): Programming language ('python', 'javascript', 'java', 'cpp').

    Returns:
        dict: Standardized result schema containing metadata, summary,
              vulnerabilities list, and patched code.
    """
    lang = mock_scanner.normalize_language(language)

    # 1. Attempt to invoke live teammate backend if available
    if is_live_backend_available():
        try:
            import backend.ai_engine as ai_mod
            raw_res = ai_mod.analyze_code(code, lang)
            normalized = _normalize_backend_result(raw_res, lang, engine=ENGINE_LIVE)
            return normalized
        except Exception as err:
            # Fall through to mock engine with error notice
            fallback_res = mock_scanner.analyze_code(code, lang)
            fallback_res["metadata"]["engine"] = ENGINE_MOCK
            fallback_res["metadata"]["backend_fallback_reason"] = f"Teammate backend error: {str(err)}"
            fallback_res["metadata"]["is_mock"] = True
            return fallback_res

    # 2. Local rule-based scanner execution
    result = mock_scanner.analyze_code(code, lang)
    result["metadata"]["engine"] = ENGINE_MOCK
    result["metadata"]["is_mock"] = True
    return result


def _normalize_backend_result(raw: Dict[str, Any], language: str, engine: str) -> Dict[str, Any]:
    """
    Ensures any teammate backend output conforms strictly to the standard
    SecureCode AI dictionary schema expected by the frontend.
    """
    meta = raw.get("metadata", {})
    summary = raw.get("summary", {})
    vulns = raw.get("vulnerabilities", [])

    return {
        "status": raw.get("status", "success"),
        "is_mock": False,
        "scan_notice": f"Analysis performed by {engine}.",
        "metadata": {
            "language": language,
            "total_lines": meta.get("total_lines", 0),
            "analyzed_at": meta.get("analyzed_at", datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            "scanner": engine,
            "engine": engine,
            "is_mock": False
        },
        "summary": {
            "health_score": summary.get("health_score", 100),
            "total_vulnerabilities": summary.get("total_vulnerabilities", len(vulns)),
            "critical": summary.get("critical", 0),
            "high": summary.get("high", 0),
            "medium": summary.get("medium", 0),
            "low": summary.get("low", 0),
            "status": summary.get("status", "COMPLETED")
        },
        "vulnerabilities": vulns,
        "patched_code": raw.get("patched_code", "")
    }
