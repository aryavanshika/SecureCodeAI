"""
Backend package for SecureCode AI.
Contains security analysis, AI patching engines, and static rule checkers.
"""
