"""
=============================================================================
Tests for Multi-File Project Scanner (tests/test_project_scanner.py)
=============================================================================
"""

import unittest
import zipfile
import io
import project_scanner as ps


class TestProjectScanner(unittest.TestCase):

    def _create_test_zip(self, file_dict):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for name, content in file_dict.items():
                zf.writestr(name, content)
        return buf.getvalue()

    def test_valid_project_scan(self):
        files = {
            "app.py": "import os\nos.system('ping ' + target_host)",
            "utils/db.js": "const q = 'SELECT * FROM u WHERE id = ' + req.id;\ndb.query(q);",
            "notes.txt": "Just documentation notes."
        }
        zip_data = self._create_test_zip(files)
        report = ps.scan_zip_project(zip_data, "test_proj.zip")

        self.assertEqual(report["files_scanned"], 2)  # app.py and utils/db.js (notes.txt ignored)
        self.assertGreater(report["summary"]["total_vulnerabilities"], 0)
        self.assertIn("file_results", report)

        csv_out = ps.generate_consolidated_csv(report)
        self.assertIn("Filename", csv_out)
        self.assertIn("app.py", csv_out)

    def test_zip_slip_path_traversal_rejection(self):
        files = {
            "../../etc/passwd": "root:x:0:0:root:/root:/bin/bash",
            "safe.py": "print('hello')"
        }
        zip_data = self._create_test_zip(files)
        with self.assertRaises(ps.ProjectScannerError) as ctx:
            ps.scan_zip_project(zip_data, "malicious.zip")
        self.assertIn("Zip Slip", str(ctx.exception))

    def test_empty_zip_handling(self):
        with self.assertRaises(ps.ProjectScannerError):
            ps.scan_zip_project(b"", "empty.zip")

    def test_no_supported_files(self):
        files = {
            "readme.md": "# Docs",
            "data.csv": "a,b,c"
        }
        zip_data = self._create_test_zip(files)
        with self.assertRaises(ps.ProjectScannerError) as ctx:
            ps.scan_zip_project(zip_data, "docs.zip")
        self.assertIn("No supported source code files", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
