"""
=============================================================================
SecureCode AI - Automated Unit Test Suite (tests/test_scanner.py)
=============================================================================
Tests all 9 vulnerability detection rules, false positive avoidance,
multi-language support, report exporters, and interface compatibility.
=============================================================================
"""

import unittest
import mock_scanner as ms
from utils.report_generator import (
    generate_json_report,
    generate_csv_report,
    generate_text_summary,
    generate_markdown_report
)


class TestVulnerabilityDetectionEngine(unittest.TestCase):

    # -------------------------------------------------------------------------
    # 1. SQL Injection (CWE-89) Tests
    # -------------------------------------------------------------------------
    def test_sqli_python_detection(self):
        code = 'cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")'
        res = ms.analyze_code(code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-89", cwes)
        self.assertEqual(res["vulnerabilities"][0]["severity"], "Critical")

    def test_sqli_javascript_detection(self):
        code = "db.query(`SELECT * FROM accounts WHERE name = ${userName}`);"
        res = ms.analyze_code(code, "javascript")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-89", cwes)

    def test_sqli_java_detection(self):
        code = 'ResultSet rs = stmt.executeQuery("SELECT * FROM users WHERE id = " + userId);'
        res = ms.analyze_code(code, "java")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-89", cwes)

    def test_sqli_false_positive_parameterized(self):
        # Parameterized query with %s placeholder should NOT be flagged as SQLi
        safe_code = 'cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))'
        res = ms.analyze_code(safe_code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertNotIn("CWE-89", cwes)

    # -------------------------------------------------------------------------
    # 2. Hardcoded Credentials (CWE-798) Tests
    # -------------------------------------------------------------------------
    def test_hardcoded_secret_detection(self):
        code = 'api_key = "sk-live-98f39182a4d9c72e1048b"'
        res = ms.analyze_code(code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-798", cwes)
        self.assertEqual(res["vulnerabilities"][0]["severity"], "Critical")

    def test_hardcoded_secret_fp_avoidance(self):
        # Loading from env var should NOT be flagged
        safe_code = 'api_key = os.getenv("API_KEY")'
        res = ms.analyze_code(safe_code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertNotIn("CWE-798", cwes)

        # Placeholder string should NOT be flagged
        placeholder_code = 'api_key = "YOUR_API_KEY_HERE"'
        res2 = ms.analyze_code(placeholder_code, "python")
        cwes2 = [v["cwe"] for v in res2["vulnerabilities"]]
        self.assertNotIn("CWE-798", cwes2)

    # -------------------------------------------------------------------------
    # 3. Command Injection (CWE-78) Tests
    # -------------------------------------------------------------------------
    def test_command_injection_python(self):
        code = 'os.system("ping -c 1 " + target_ip)'
        res = ms.analyze_code(code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-78", cwes)
        self.assertEqual(res["vulnerabilities"][0]["severity"], "Critical")

    def test_command_injection_fp_avoidance(self):
        # Safe subprocess execution with shell=False should NOT be flagged
        safe_code = "subprocess.run(['ping', '-c', '1', target_ip], shell=False)"
        res = ms.analyze_code(safe_code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertNotIn("CWE-78", cwes)

    # -------------------------------------------------------------------------
    # 4. Cross-Site Scripting (XSS) (CWE-79) Tests
    # -------------------------------------------------------------------------
    def test_xss_javascript_detection(self):
        code = 'document.getElementById("output").innerHTML = "<h3>" + query + "</h3>";'
        res = ms.analyze_code(code, "javascript")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-79", cwes)
        self.assertEqual(res["vulnerabilities"][0]["severity"], "High")

    def test_xss_python_detection(self):
        code = 'return render_template_string("<h1>Welcome " + user_input + "</h1>")'
        res = ms.analyze_code(code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-79", cwes)

    def test_xss_fp_sanitized(self):
        # Assignment with DOMPurify sanitizer should NOT be flagged
        safe_code = 'element.innerHTML = DOMPurify.sanitize(userContent);'
        res = ms.analyze_code(safe_code, "javascript")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertNotIn("CWE-79", cwes)

    # -------------------------------------------------------------------------
    # 5. Weak Cryptographic Hashing (CWE-327) Tests
    # -------------------------------------------------------------------------
    def test_weak_crypto_detection(self):
        code = 'pwd_hash = hashlib.md5(password.encode()).hexdigest()'
        res = ms.analyze_code(code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-327", cwes)
        self.assertEqual(res["vulnerabilities"][0]["severity"], "Medium")

    def test_weak_crypto_java(self):
        code = 'MessageDigest md = MessageDigest.getInstance("MD5");'
        res = ms.analyze_code(code, "java")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-327", cwes)

    # -------------------------------------------------------------------------
    # 6. Insecure Deserialization (CWE-502) Tests
    # -------------------------------------------------------------------------
    def test_deserialization_python_detection(self):
        code = 'data = pickle.loads(untrusted_payload)'
        res = ms.analyze_code(code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-502", cwes)
        self.assertEqual(res["vulnerabilities"][0]["severity"], "High")

    def test_deserialization_fp_avoidance(self):
        # yaml.safe_load is secure and should NOT be flagged
        safe_code = 'config = yaml.safe_load(yaml_file)'
        res = ms.analyze_code(safe_code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertNotIn("CWE-502", cwes)

    # -------------------------------------------------------------------------
    # 7. Path Traversal (CWE-22) Tests
    # -------------------------------------------------------------------------
    def test_path_traversal_python(self):
        code = 'with open(f"/app/uploads/{filename}", "r") as f:'
        res = ms.analyze_code(code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-22", cwes)
        self.assertEqual(res["vulnerabilities"][0]["severity"], "High")

    def test_path_traversal_javascript(self):
        code = 'const data = fs.readFileSync(req.query.file);'
        res = ms.analyze_code(code, "javascript")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-22", cwes)

    def test_path_traversal_fp_avoidance(self):
        # Using os.path.basename prevents directory traversal
        safe_code = 'safe_path = os.path.basename(user_input)\nwith open(safe_path, "r") as f:'
        res = ms.analyze_code(safe_code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertNotIn("CWE-22", cwes)

    # -------------------------------------------------------------------------
    # 8. Debug Mode Exposure (CWE-489) Tests
    # -------------------------------------------------------------------------
    def test_debug_mode_python(self):
        code = 'app.run(host="0.0.0.0", port=5000, debug=True)'
        res = ms.analyze_code(code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-489", cwes)
        self.assertEqual(res["vulnerabilities"][0]["severity"], "Medium")

    def test_debug_mode_cpp(self):
        code = '#define DEBUG 1'
        res = ms.analyze_code(code, "cpp")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-489", cwes)

    def test_debug_mode_fp_avoidance(self):
        # debug=False is safe and should NOT be flagged
        safe_code = 'app.run(host="0.0.0.0", port=5000, debug=False)'
        res = ms.analyze_code(safe_code, "python")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertNotIn("CWE-489", cwes)

    # -------------------------------------------------------------------------
    # 9. Unsafe C/C++ Buffer Operations (CWE-120) Tests
    # -------------------------------------------------------------------------
    def test_unsafe_buffer_strcpy(self):
        code = 'strcpy(destBuffer, srcUserInput);'
        res = ms.analyze_code(code, "cpp")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-120", cwes)
        self.assertEqual(res["vulnerabilities"][0]["severity"], "Critical")

    def test_unsafe_buffer_sprintf(self):
        code = 'sprintf(command, "echo %s", userInput);'
        res = ms.analyze_code(code, "cpp")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertIn("CWE-120", cwes)

    def test_safe_buffer_strncpy_fp_avoidance(self):
        # strncpy is bounded and should NOT be flagged by strcpy regex
        safe_code = 'strncpy(destBuffer, srcUserInput, sizeof(destBuffer) - 1);'
        res = ms.analyze_code(safe_code, "cpp")
        cwes = [v["cwe"] for v in res["vulnerabilities"]]
        self.assertNotIn("CWE-120", cwes)

    # -------------------------------------------------------------------------
    # General Engine Quality & Interface Tests
    # -------------------------------------------------------------------------
    def test_empty_code_handling(self):
        res = ms.analyze_code("", "python")
        self.assertEqual(res["status"], "empty")
        self.assertEqual(res["summary"]["total_vulnerabilities"], 0)
        self.assertEqual(res["summary"]["health_score"], 100)

    def test_comment_lines_ignored(self):
        # Lines commented out should NOT trigger findings
        code = '# cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")'
        res = ms.analyze_code(code, "python")
        self.assertEqual(res["summary"]["total_vulnerabilities"], 0)

    def test_line_number_accuracy(self):
        code = "\n\napi_key = 'sk-live-98f39182a4d9c72e1048b'\n"
        res = ms.analyze_code(code, "python")
        self.assertEqual(len(res["vulnerabilities"]), 1)
        self.assertEqual(res["vulnerabilities"][0]["line_number"], 3)

    def test_all_demo_snippets_valid(self):
        for lang in ["python", "javascript", "java", "cpp"]:
            snippet = ms.get_demo_snippet(lang)
            res = ms.analyze_code(snippet, lang)
            self.assertGreater(res["summary"]["total_vulnerabilities"], 0)
            self.assertTrue(len(res["patched_code"]) > 0)
            self.assertTrue(res["is_mock"])

    def test_report_exporters_compatibility(self):
        res = ms.analyze_code(ms.get_demo_snippet("python"), "python")
        json_rep = generate_json_report(res)
        csv_rep = generate_csv_report(res)
        txt_rep = generate_text_summary(res, "test.py")
        md_rep = generate_markdown_report(res, "test.py")

        self.assertIn("vulnerabilities", json_rep)
        self.assertIn("Severity", csv_rep)
        self.assertIn("SECURECODE AI", txt_rep)
        self.assertIn("CWE", md_rep)


if __name__ == "__main__":
    unittest.main()
