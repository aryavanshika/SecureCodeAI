"""
=============================================================================
Tests for AutoFix & Patch Verifier (tests/test_patch_verifier.py)
=============================================================================
Tests:
- AutoFix patch generation and safety rationale
- Patch verification through empirical rescanning
- Verification statuses: 'Resolved by scanner rule', 'Still detected'
=============================================================================
"""

import unittest
import backend_adapter as ba
import autofix as af
import patch_verifier as pv


class TestPatchVerifier(unittest.TestCase):

    def test_autofix_generation(self):
        vulnerable_code = "cursor.execute(f'SELECT * FROM users WHERE id = {user_id}')"
        analysis = ba.analyze_code(vulnerable_code, "python")
        self.assertGreater(len(analysis["vulnerabilities"]), 0)

        vuln = analysis["vulnerabilities"][0]
        patch_info = af.generate_patch_for_vulnerability(vulnerable_code, vuln, "python")

        self.assertIn("patched_code", patch_info)
        self.assertIn("rationale", patch_info)
        self.assertTrue(patch_info["is_educational_sample"])

    def test_patch_verification_resolved(self):
        vulnerable_code = "cursor.execute(f'SELECT * FROM users WHERE id = {user_id}')"
        orig_analysis = ba.analyze_code(vulnerable_code, "python")
        vuln = orig_analysis["vulnerabilities"][0]

        # Patch it
        patch_info = af.generate_patch_for_vulnerability(vulnerable_code, vuln, "python")
        patched_code = patch_info["patched_code"]

        # Verify patch by rescanning
        res = pv.verify_patch(
            original_analysis=orig_analysis,
            patched_code=patched_code,
            target_vuln_cwe="CWE-89",
            language="python"
        )

        self.assertEqual(res["status"], pv.STATUS_RESOLVED)
        self.assertTrue(res["is_verified"])
        self.assertIn("CWE-89", res["resolved_cwes"])
        self.assertGreaterEqual(res["score_delta"], 0)

    def test_patch_verification_still_detected(self):
        # A patch that didn't change anything
        vulnerable_code = "cursor.execute(f'SELECT * FROM users WHERE id = {user_id}')"
        orig_analysis = ba.analyze_code(vulnerable_code, "python")

        res = pv.verify_patch(
            original_analysis=orig_analysis,
            patched_code=vulnerable_code,  # unchanged!
            target_vuln_cwe="CWE-89",
            language="python"
        )

        self.assertEqual(res["status"], pv.STATUS_STILL_DETECTED)
        self.assertFalse(res["is_verified"])


if __name__ == "__main__":
    unittest.main()
