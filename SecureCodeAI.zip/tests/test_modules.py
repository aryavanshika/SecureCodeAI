"""
=============================================================================
Tests for Risk Analyzer, Secrets, Dependencies & Attack Lab (tests/test_modules.py)
=============================================================================
"""

import unittest
import risk_analyzer as ra
import secret_detector as sd
import dependency_scanner as ds
import attack_simulator as atk_sim


class TestSecurityModules(unittest.TestCase):

    def test_risk_analyzer(self):
        sample_vulns = [
            {"id": "V-1", "severity": "Critical", "cwe": "CWE-89", "name": "SQLi", "line_number": 10},
            {"id": "V-2", "severity": "High", "cwe": "CWE-79", "name": "XSS", "line_number": 20}
        ]
        report = ra.analyze_project_risk(sample_vulns)
        self.assertGreater(report["overall_risk_score"], 0)
        self.assertIn("risk_tier", report)
        self.assertIsNotNone(report["highest_priority_vuln"])
        self.assertEqual(len(report["remediation_order"]), 2)

    def test_secret_detector_masking(self):
        code = 'openai_key = "sk-live-1234567890abcdef1234567890"'
        secrets = sd.scan_for_secrets(code, "test.py")
        self.assertEqual(len(secrets), 1)
        masked = secrets[0]["masked_secret"]
        self.assertIn("*", masked)
        # Ensure raw full secret is NEVER returned
        self.assertNotIn("1234567890abcdef", masked)

    def test_dependency_scanner_manifest(self):
        req_content = "requests==2.28.0\nflask==2.1.0\nurllib3==1.26.5\n"
        res = ds.scan_manifest_dependencies(req_content, "requirements.txt")
        self.assertGreater(res["vulnerable_count"], 0)
        cves = [v["cve"] for v in res["vulnerabilities"]]
        self.assertIn("CVE-2023-32681", cves)

    def test_attack_simulator_catalog(self):
        sim = atk_sim.get_simulation("sqli")
        self.assertEqual(sim["cwe"], "CWE-89")
        self.assertIn("vulnerable_code", sim)
        self.assertIn("secure_code", sim)
        self.assertIn("vulnerable_sim_output", sim)
        self.assertIn("secure_sim_output", sim)


if __name__ == "__main__":
    unittest.main()
