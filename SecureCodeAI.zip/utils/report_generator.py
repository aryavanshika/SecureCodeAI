"""
=============================================================================
SecureCode AI - Report Generator Utility
=============================================================================
Provides exporters for:
- JSON Report (.json)
- CSV Vulnerability Matrix (.csv) via Pandas
- Text Executive Summary (.txt)
- Markdown Audit Document (.md)
=============================================================================
"""

import json
import pandas as pd
from typing import Dict, Any


def generate_json_report(analysis_result: Dict[str, Any]) -> str:
    """Serializes analysis output to pretty-printed JSON."""
    return json.dumps(analysis_result, indent=2)


def generate_csv_report(analysis_result: Dict[str, Any]) -> str:
    """Generates a CSV string of identified vulnerabilities using Pandas."""
    vulns = analysis_result.get("vulnerabilities", [])
    if not vulns:
        df = pd.DataFrame([{
            "ID": "N/A",
            "Name": "No vulnerabilities detected",
            "Severity": "Clean",
            "CWE": "N/A",
            "Line": 0,
            "Snippet": "",
            "Description": "The scanned code has no detected security issues.",
            "Recommendation": "Keep following secure coding best practices."
        }])
    else:
        rows = []
        for v in vulns:
            rows.append({
                "ID": v.get("id"),
                "Name": v.get("name"),
                "Severity": v.get("severity"),
                "CWE": v.get("cwe"),
                "Line": v.get("line_number"),
                "Snippet": v.get("code_snippet"),
                "Description": v.get("description"),
                "Recommendation": v.get("recommendation"),
                "Suggested_Fix": v.get("suggested_fix")
            })
        df = pd.DataFrame(rows)

    return df.to_csv(index=False)


def generate_text_summary(analysis_result: Dict[str, Any], file_name: str = "Source_Code") -> str:
    """Generates a plain-text executive summary."""
    meta = analysis_result.get("metadata", {})
    summary = analysis_result.get("summary", {})
    vulns = analysis_result.get("vulnerabilities", [])

    lines = [
        "=" * 70,
        "SECURECODE AI - VULNERABILITY AUDIT SUMMARY (DEMO SCAN)",
        "=" * 70,
        f"File Analyzed:       {file_name}",
        f"Language:            {meta.get('language', 'Unknown').upper()}",
        f"Timestamp:           {meta.get('analyzed_at', 'N/A')}",
        f"Scanner Engine:      {meta.get('scanner', 'Mock Engine')}",
        f"Estimated Health:    {summary.get('health_score', 100)} / 100 (Demo Score)",
        f"Total Scanned Lines: {meta.get('total_lines', 0)}",
        f"Total Findings:      {summary.get('total_vulnerabilities', 0)}",
        "-" * 70,
        f"CRITICAL: {summary.get('critical', 0)} | HIGH: {summary.get('high', 0)} | MEDIUM: {summary.get('medium', 0)} | LOW: {summary.get('low', 0)}",
        "-" * 70,
        "",
        "DETAILED FINDINGS:"
    ]

    if not vulns:
        lines.append("  [+] No vulnerabilities or security risks were identified.")
    else:
        for idx, v in enumerate(vulns, start=1):
            lines.extend([
                f"[{idx}] {v.get('severity', 'UNKNOWN').upper()}: {v.get('name')} ({v.get('cwe')})",
                f"    Line Number:     {v.get('line_number')}",
                f"    Code Snippet:    {v.get('code_snippet')}",
                f"    Description:     {v.get('description')}",
                f"    Recommendation:  {v.get('recommendation')}",
                f"    Suggested Fix:   {v.get('suggested_fix')}",
                ""
            ])

    lines.extend([
        "=" * 70,
        "DISCLAIMER: This report was produced by a simulated rule-based demonstration engine.",
        "=" * 70
    ])

    return "\n".join(lines)


def generate_markdown_report(analysis_result: Dict[str, Any], file_name: str = "Source_Code") -> str:
    """Generates a GitHub Flavored Markdown report."""
    meta = analysis_result.get("metadata", {})
    summary = analysis_result.get("summary", {})
    vulns = analysis_result.get("vulnerabilities", [])

    lines = [
        "# 🛡️ SecureCode AI - Security Audit Report (MOCK / DEMO)",
        "",
        "> ⚠️ **Simulation Notice:** Findings were generated via a demonstration rule-based scanner.",
        "",
        f"- **Target File:** `{file_name}`",
        f"- **Language:** `{meta.get('language', 'Unknown').upper()}`",
        f"- **Audit Date:** `{meta.get('analyzed_at', 'N/A')}`",
        f"- **Security Score Estimate:** `{summary.get('health_score', 100)} / 100`",
        f"- **Total Identified Issues:** `{summary.get('total_vulnerabilities', 0)}`",
        "",
        "## Severity Breakdown",
        f"- 🔴 **Critical:** `{summary.get('critical', 0)}`",
        f"- 🟠 **High:** `{summary.get('high', 0)}`",
        f"- 🟡 **Medium:** `{summary.get('medium', 0)}`",
        f"- 🟢 **Low:** `{summary.get('low', 0)}`",
        "",
        "## Detailed Findings",
        ""
    ]

    if not vulns:
        lines.append("✅ No vulnerabilities detected.")
    else:
        for idx, v in enumerate(vulns, start=1):
            lines.extend([
                f"### {idx}. [{v.get('severity')}] {v.get('name')} ({v.get('cwe')})",
                f"- **Line:** `{v.get('line_number')}`",
                f"- **Affected Code:** `{v.get('code_snippet')}`",
                f"- **Description:** {v.get('description')}",
                f"- **Recommendation:** {v.get('recommendation')}",
                f"- **Suggested Fix:** `{v.get('suggested_fix')}`",
                ""
            ])

    return "\n".join(lines)
