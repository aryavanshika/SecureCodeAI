"""
Preloaded sample codes with known vulnerabilities for rapid testing & demos.
Includes Python, JavaScript, Java, and C++.
"""

SAMPLE_CODES = {
    "python": {
        "title": "Python: Insecure Web API (SQLi, Secret, Command Injection)",
        "code": '''import os
import sqlite3
import hashlib

# SECURITY ISSUE: Hardcoded sensitive secret
API_KEY = "sk-live-98f39182a4d9c72e1048b"

def authenticate_user(username, password):
    # SECURITY ISSUE: Using weak MD5 hash
    hashed_password = hashlib.md5(password.encode()).hexdigest()
    
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    
    # SECURITY ISSUE: SQL Injection via f-string
    query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{hashed_password}'"
    cursor.execute(f"SELECT * FROM users WHERE username = {username}")
    
    user = cursor.fetchone()
    return user

def run_network_diagnostic(target_ip):
    # SECURITY ISSUE: OS Command Injection
    command = "ping -c 1 " + target_ip
    os.system(command)
    return "Diagnostic initiated"

def handle_request():
    try:
        user = authenticate_user("admin", "admin123")
        run_network_diagnostic("127.0.0.1; whoami")
    except Exception as e:
        # SECURITY ISSUE: Information Disclosure via stack trace
        return str(e)
'''
    },
    "javascript": {
        "title": "JavaScript / Node.js: Insecure Client-Side Handler (XSS, Secrets)",
        "code": '''const express = require('express');
const crypto = require('crypto');
const app = express();

// SECURITY ISSUE: Hardcoded production secret
const api_key = "prod_sec_89471928374918237";

app.get('/search', (req, res) => {
    const query = req.query.q;
    
    // SECURITY ISSUE: Weak MD5 hashing
    const queryHash = crypto.createHash('md5').update(query).digest('hex');
    
    // SECURITY ISSUE: Cross-Site Scripting (XSS) via raw innerHTML / document.write
    const container = document.getElementById('results');
    container.innerHTML = "<h3>Results for: " + query + "</h3>";
    
    res.send({ status: "ok", hash: queryHash });
});
'''
    },
    "java": {
        "title": "Java: Spring Controller (SQLi, Command Exec, Weak Crypto)",
        "code": '''import java.sql.*;
import java.security.MessageDigest;

public class VulnerableController {
    // SECURITY ISSUE: Hardcoded credentials
    private static final String password = "SuperSecretDbPassword123!";

    public void queryUserData(String userInput) throws Exception {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", password);
        Statement stmt = conn.createStatement();
        
        // SECURITY ISSUE: SQL Injection via string concatenation
        String query = "SELECT * FROM accounts WHERE id = " + userInput;
        ResultSet rs = stmt.executeQuery("SELECT * FROM accounts WHERE id = " + userInput);
        
        // SECURITY ISSUE: Weak MD5 hash
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(userInput.getBytes());
        
        // SECURITY ISSUE: Command Injection
        Runtime.getRuntime().exec("ping " + userInput);
    }
}
'''
    },
    "cpp": {
        "title": "C++: Systems Code (Buffer Overflow, strcpy, system)",
        "code": '''#include <iostream>
#include <cstring>
#include <cstdlib>

// SECURITY ISSUE: Hardcoded API Secret
const char* api_key = "cpp_secret_994821038472";

void processInput(const char* userInput) {
    char buffer[32];
    
    // SECURITY ISSUE: Dangerous unbounded memory copy (Buffer Overflow)
    strcpy(buffer, userInput);
    
    char command[64];
    // SECURITY ISSUE: Unsafe sprintf
    sprintf(command, "echo %s", buffer);
    
    // SECURITY ISSUE: Shell execution with unvalidated input
    system(command);
}

int main() {
    processInput("Very long input string designed to overflow buffer memory");
    return 0;
}
'''
    }
}
