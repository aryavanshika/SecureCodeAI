"""
Utilities package for SecureCode AI.
Contains report generators, sample snippets, and formatting helpers.
"""
